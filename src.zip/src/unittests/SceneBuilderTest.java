package unittests;

import org.junit.Test;

import static org.junit.Assert.*;

public class SceneBuilderTest {

    @Test
    public void SceneBuilder(){

    }

}